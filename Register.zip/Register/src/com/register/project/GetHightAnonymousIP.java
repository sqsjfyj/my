package com.register.project;


import com.gargoylesoftware.htmlunit.BrowserVersion;
import com.gargoylesoftware.htmlunit.WebClient;
import com.gargoylesoftware.htmlunit.WebConsole;
import com.gargoylesoftware.htmlunit.html.HtmlPage;
import org.apache.commons.logging.LogFactory;

import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class GetHightAnonymousIP {
	
    public static String getIP(String url) throws IOException {
        String html = null;
        LogFactory.getFactory().setAttribute("org.apache.commons.logging.Log", "org.apache.commons.logging.impl.NoOpLog");
        Logger.getLogger("com.gargoylesoftware").setLevel(Level.OFF);
        Logger.getLogger("org.apache.http.client").setLevel(Level.OFF);
        WebClient webClient = new WebClient(BrowserVersion.FIREFOX_52);
        webClient.getOptions().setCssEnabled(false);
        webClient.getOptions().setJavaScriptEnabled(true);
        webClient.getOptions().setThrowExceptionOnScriptError(false);
        try {
            HtmlPage htmlPage = webClient.getPage(url);
            html = htmlPage.toString();
        }catch (Exception e){
            e.printStackTrace();
        }finally {
            webClient.close();
        }
        return html;
    }

}
