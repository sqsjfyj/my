package com.register.project;

import java.io.EOFException;
import java.io.IOException;
import java.net.ConnectException;
import java.net.SocketException;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.http.*;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;

import static org.apache.http.Consts.UTF_8;


public class Register {

	//获取主页Cookie用于登录或注册
	public static Map<String, String> getCookie() throws KeyManagementException, NoSuchAlgorithmException, IOException {
		//List<String> cookies = new ArrayList<>();
		Map<String, String> cookies = new HashMap<>();
		CloseableHttpClient httpClient = HttpClientManager.getHttpClient();
		HttpGet httpGet = new HttpGet("https://www.instagram.com/");
		httpGet.setHeader("Connection", "keep-alive");
		httpGet.setHeader("User-Agent", "Mozilla/5.0 (Windows NT 10.0; WOW64; rv:59.0) Gecko/20100101 Firefox/59.0");
		try {
			CloseableHttpResponse httpResponse = httpClient.execute(httpGet);
			Header[] headers = httpResponse.getHeaders("Set-Cookie");
			for (Header header : headers){
				if (header.getValue().startsWith("rur")) {
					cookies.put("rur", header.getValue().substring("rur=".length(), header.getValue().indexOf(";")));
					//System.out.println("rur:" + cookies.get("rur"));
				}else if (header.getValue().startsWith("csrftoken")){
					cookies.put("csrftoken", header.getValue().substring("csrftoken=".length(), header.getValue().indexOf(";")));
					//System.out.println("csrftoken:" + cookies.get("csrftoken"));
				}else if (header.getValue().startsWith("mid")){
					cookies.put("mid", header.getValue().substring("mid=".length(), header.getValue().indexOf(";")));
					//System.out.println("mid:" + cookies.get("mid"));
				}
			}
		}catch (ConnectException e){
			System.out.println("ins连接超时");
		}finally {
			httpClient.close();
		}
		return cookies;
	}


	//注册
	public static String registerByEmail(String email, String allName, String username, String password, String ip, Map<String, String> cookies) throws IOException, NoSuchAlgorithmException, KeyManagementException {
		String result = null;
		CloseableHttpClient closeableHttpClient = HttpClientManager.getHttpClient(ip);
		List<NameValuePair> params = new ArrayList<>();
		params.add(new BasicNameValuePair("email", email));
		params.add(new BasicNameValuePair("first_name", allName));
		params.add(new BasicNameValuePair("username", username));
		params.add(new BasicNameValuePair("password", password));
		HttpPost httpPost = new HttpPost("https://www.instagram.com/accounts/web_create_ajax/");
		httpPost.setHeader("Connection", "keep-alive");
		httpPost.setHeader("User-Agent", "Mozilla/5.0 (Windows NT 10.0; WOW64; rv:59.0) Gecko/20100101 Firefox/59.0");
		httpPost.setHeader("Referer", "https://www.instagram.com/");
		httpPost.setHeader("Cookie", "rur=" + cookies.get("rur") + "; " + "csrftoken=" + cookies.get("csrftoken") + "; " + "mid=" + cookies.get("mid"));
		httpPost.setHeader("X-CSRFToken", cookies.get("csrftoken"));
		httpPost.setEntity(new UrlEncodedFormEntity(params, UTF_8));
		try {
			CloseableHttpResponse httpResponse = closeableHttpClient.execute(httpPost);
			if (httpResponse.getStatusLine().getStatusCode() == HttpStatus.SC_OK) {
				String json = EntityUtils.toString(httpResponse.getEntity(), "utf-8");
				result = json;
			}else {
				if (httpResponse.getStatusLine().getStatusCode() == 429){
					result = "请求次数过多";
				}else {
					result = "状态码：" + String.valueOf(httpResponse.getStatusLine().getStatusCode());
				}
			}

		}catch (ConnectException e){
			result = "请求超时";
		}catch (NoHttpResponseException e){
			result = "无响应";
		}catch (SocketException e) {
			// TODO: handle exception
			result = "中断";
		}catch (EOFException e) {
			// TODO: handle exception
			result = "SSL peer shut down incorrectly";
		}finally {
			closeableHttpClient.close();
		}
		return result;
	}


	public static String registerByEmail(String email, String allName, String username, String password, Map<String, String> cookies) throws IOException, NoSuchAlgorithmException, KeyManagementException {
		String result = null;
		CloseableHttpClient closeableHttpClient = HttpClientManager.getHttpClient();
		List<NameValuePair> params = new ArrayList<>();
		params.add(new BasicNameValuePair("email", email));
		params.add(new BasicNameValuePair("first_name", allName));
		params.add(new BasicNameValuePair("username", username));
		params.add(new BasicNameValuePair("password", password));
		params.add(new BasicNameValuePair("seamless_login_enabled", "1"));
		HttpPost httpPost = new HttpPost("https://www.instagram.com/accounts/web_create_ajax/");
		httpPost.setHeader("Connection", "keep-alive");
		httpPost.setHeader("User-Agent", "Mozilla/5.0 (Windows NT 10.0; WOW64; rv:59.0) Gecko/20100101 Firefox/59.0");
		httpPost.setHeader("Referer", "https://www.instagram.com/");
		httpPost.setHeader("Cookie", "rur=" + cookies.get("rur") + "; " + "csrftoken=" + cookies.get("csrftoken") + "; " + "mid=" + cookies.get("mid"));
		httpPost.setHeader("X-CSRFToken", cookies.get("csrftoken"));
		httpPost.setEntity(new UrlEncodedFormEntity(params, UTF_8));
		try {
			CloseableHttpResponse httpResponse = closeableHttpClient.execute(httpPost);
			if (httpResponse.getStatusLine().getStatusCode() == HttpStatus.SC_OK) {
				String json = EntityUtils.toString(httpResponse.getEntity(), "utf-8");
				result = json;
//				Header[] headers = httpResponse.getAllHeaders();
//				for(Header header : headers) {
//					System.out.println(header.getValue());
//				}
			}else {
				if (httpResponse.getStatusLine().getStatusCode() == 429){
					result = "请求次数过多";
				}else {
					result = "状态码：" + String.valueOf(httpResponse.getStatusLine().getStatusCode());
				}
			}

		}catch (ConnectException e){
			result = "请求超时";
		}catch (NoHttpResponseException e){
			result = "无响应";
		}catch (SocketException e) {
			// TODO: handle exception
			result = "中断";
		}catch (EOFException e) {
			// TODO: handle exception
			result = "SSL peer shut down incorrectly";
		}finally {
			closeableHttpClient.close();
		}
		return result;
	}


	//注册100个
	public static void registerOneHundred(List<Account> accountsList, String ipPort,Map<String, String> cookies) throws IOException, KeyManagementException, NoSuchAlgorithmException, InterruptedException {
		for (int i = 0; i < 10; i++){
			if (cookies.size() > 0) {
				//String ipPort= ProxyIPAndPort.getIPAndPort();
				System.out.println((i + 1) + "：" + registerByEmail(accountsList.get(i).getEmail(), accountsList.get(i).getAllName(), accountsList.get(i).getUsername(), accountsList.get(i).getPassword(), ipPort, cookies));
				Thread.sleep(5000);
			}

		}
	}


}
