package com.register.project;

import java.io.IOException;
import java.net.ConnectException;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.util.EntityUtils;
import org.json.JSONObject;

public class ProxyIPAndPort {

	public static List<String> getIPAndPort() throws KeyManagementException, NoSuchAlgorithmException, ClientProtocolException, IOException {
		List<String> ipList = new ArrayList<>();
		//String ipPort = null;
		int i = 0;
		while (i < 10) {
			CloseableHttpClient httpClient = HttpClientManager.getHttpClient();
			HttpGet httpGet = new HttpGet("https://gimmeproxy.com/api/getProxy?get=true&supportsHttps=true&maxCheckPeriod=3600");
			httpGet.setHeader("Connection", "keep-alive");
			httpGet.setHeader("User-Agent", "Mozilla/5.0 (Windows NT 10.0; WOW64; rv:59.0) Gecko/20100101 Firefox/59.0");
			try {
				CloseableHttpResponse httpResponse = httpClient.execute(httpGet);
				String json = EntityUtils.toString(httpResponse.getEntity(), "UTF-8");
				if(json != null && !json.equals("")) {
					JSONObject jsonObject = new JSONObject(json);
					String ip = jsonObject.getString("ip");
					String port = jsonObject.getString("port");
					String protocol = jsonObject.getString("protocol");
					if (protocol.equals("http")){
						ipList.add(ip + ":" + port);
						//ipPort = ip + ":" + port;
						//System.out.println(ipPort);
						i++;
					}
				}else {
					getIPAndPort();
				}
				//System.out.println(ip + ":" + port + " " + protocol);
				//result = ip + ":" + port;

			} catch (ConnectException e) {
				// TODO: handle exception
				System.out.println("IP获取超时");
			} finally {
				httpClient.close();
			}
		}
		//return ipPort;
		return ipList;

	}

}
