package com.register.project;

import java.io.IOException;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;



public class MyTest {

	public static void main(String[] args) throws IOException, KeyManagementException, NoSuchAlgorithmException, InterruptedException {
		Map<String, String> cookies = Register.getCookie();
		//System.out.println("d");
		//注册一个
		//MyTest.register(cookies);
		//注册100个
		MyTest.registerHundred(cookies);
		//上传头像;
		//System.out.println(UploadImg.upload("I:\\h.jpg", Login.login("1493025634@qq.com", "qwj7758258", cookies)));
		//GetHightAnonymousIP.getIP("http://proxyip.9window.com/list/gwgn/1");
	}


	//注册一个
	public static void register(Map<String, String> cookies) throws KeyManagementException, NoSuchAlgorithmException, IOException {
		if (cookies.size() > 0) {
			String email = GetEmailAndUsername.getMail();
			System.out.println(email);
			String html = GetEmailAndUsername.getUsername("chifantht", "1");
			Document document = Jsoup.parse(html);
			Elements elements = document.getElementsByClass("bizname");
			String username = elements.get(0).text();
			System.out.println(username);
//			List<String> ipPorts = ProxyIPAndPort.getIPAndPort();
//			String ipPort = ipPorts.get(0);
//			System.out.println(ipPort);
			System.out.println(Register.registerByEmail(email, "qiuwenjie", username, "qwj9389", /*ProxyIPAndPort.getIPAndPort(),*/ cookies));
		}
	}

	//100个
	public static void registerHundred(Map<String, String> cookies) throws KeyManagementException, NoSuchAlgorithmException, IOException, InterruptedException {
		//100个账户
		List<Account> accountsList = new ArrayList<>();
		List<String> email = MyTest.getHundredEmail();
		List<String> username = MyTest.getHundredUsername();
		//List<String> ipList = ProxyIPAndPort.getIPAndPort();
		for (int i = 0; i < 10; i++){
			//Account account = new Account("1493025634@qq.com", "dsufighdi", "wdfisrgh", "a123456789");
			Account account = new Account(email.get(i), "lajibiao", username.get(i), "wdiug6459");
			accountsList.add(account);
		}

		for(Account account : accountsList) {
			System.out.println(account.getEmail() + " " + account.getAllName() + " " + account.getUsername() + " " + account.getPassword());
		}

		//注册100个
		if (cookies.size() > 0) {
			Register.registerOneHundred(accountsList, "211.79.61.8:3128", cookies);
		}

	}


	//获取100个邮箱
	public static List<String> getHundredEmail() throws KeyManagementException, NoSuchAlgorithmException, IOException, InterruptedException {
		String[] ip = new String[] {"180.104.62.234:9000", "115.218.120.194:9000", "180.118.32.17:9000", "121.232.147.199:9000", "183.158.206.176:9000", "115.223.251.198:9000", "114.234.83.67:9000", "115.223.219.240:9000", "125.117.134.223:9000", "121.232.147.189:9000"};
		List<String> emailList = new ArrayList<>();
		for (int i = 0; i < 10; i++) {
			String email = GetEmailAndUsername.getMail();
			emailList.add(email);
			System.out.println(email);
			Thread.sleep(1000);
		}
		return emailList;
	}

	//获取100个用户名
	public static List<String> getHundredUsername() throws KeyManagementException, NoSuchAlgorithmException, IOException {
		List<String> usernameList = new ArrayList<>();
		String html = GetEmailAndUsername.getUsername("pyw", "40");
		Document document = Jsoup.parse(html);
		Elements biznames = document.getElementsByClass("bizname");
		for(int i = 0; i < 10; i++) {
			String username = biznames.get(i).text();
			usernameList.add(username);
			System.out.println(username);
		}
		return usernameList;
	}








}
